package com.mycompany.feriaempresarial;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private String nombre;
    private String sector;
    private String correo;
    private Stand stand;
    private List<Comentario> comentarios = new ArrayList<>();
    private List<Visitante> visitantes = new ArrayList<>();

    public Empresa(String nombre, String sector, String correo){
        this.nombre = nombre;
        this.sector = sector;
        this.correo = correo;
        this.stand = null;
        this.comentarios = null;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public void setSector(String sector){
        this.sector = sector;
    }

    public void setCorreo(String correo){
        this.correo = correo;
    }

    public void setStand(Stand stand){
        this.stand = stand;
    }

    public String getNombre(){
        return nombre;
    }

    public String getSector(){
        return sector;
    }

    public String getCorreo(){
        return correo;
    }

    public Stand getStand(){
        return stand;
    }

    public void addVisitante(Visitante visitante){
        visitantes.add(visitante);
        stand.addVisitante(visitante);
    }

    public void getVisitantes(){
        for(Visitante visitante : visitantes){
            System.out.println(visitante);
        }
    }

    public void addComentario(Comentario comentario){
        comentarios.add(comentario);
    }

    public void getComentarios(){
        for(Comentario comentario : comentarios){
            System.out.println(comentario);
        }
    }

    @Override
    public String toString(){
        return "Empresa{ Nombre=" + nombre + '\'' +
                ", Sector=" + sector + '\'' +
                ", Correo=" + correo + '\'' +
                stand + '\'' +
                "}";
    }
}