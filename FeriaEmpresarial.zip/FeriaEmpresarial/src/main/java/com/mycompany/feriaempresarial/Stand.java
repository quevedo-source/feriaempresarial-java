package com.mycompany.feriaempresarial;

import java.util.ArrayList;
import java.util.List;

public class Stand {
    private int id;
    private String ubicacion;
    private String tamano;
    private Empresa empresa;
    private List<Comentario> comentarios = new ArrayList<>();
    private List<Visitante> visitantes = new ArrayList<>();

    public Stand(int id, String ubicacion, String tamano){
        this.id = id;
        this.ubicacion = ubicacion;
        this.tamano = tamano;
        this.empresa = null;
        this.comentarios = null;
        this.visitantes = null;
    }

    public void setId(int id){
        this.id = id;
    }

    public void setUbicacion(String ubicacion){
        this.ubicacion = ubicacion;
    }

    public void setTamano(String tamano){
        this.tamano = tamano;
    }

    public void setEmpresa(Empresa empresa){
        this.empresa = empresa;
    }

    public int getId(){
        return id;
    }

    public String getUbicacion(){
        return ubicacion;
    }

    public String getTamano(){
        return tamano;
    }

    public Empresa getEmpresa(){
        return empresa;
    }

    public String getNombreEmpresa(){
        return this.empresa.getNombre();
    }

    public void addVisitante(Visitante visitante){
        visitantes.add(visitante);
        System.out.println("Visitante agregado al stand");
    }

    public void getVisitantes(){
        for(Visitante visitante : visitantes){
            System.out.println(visitante);
        }
    }

    public void addComentario(Comentario comentario, int year, int mes, int dia){
        comentario.setFecha(year, mes, dia);
        comentarios.add(comentario);
        empresa.addComentario(comentario);
    }

    public void getComentarios(){
        for(Comentario comentario : comentarios){
            System.out.println(comentario);
        }
    }

    @Override
    public String toString(){
        return "Stand{ Id=" + id + '\'' +
                ", Ubicacion=" + ubicacion + '\'' +
                ", Tamaño=" + tamano + '\'' +
                "}";
    }
}