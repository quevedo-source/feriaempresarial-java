package com.mycompany.feriaempresarial;

import java.time.LocalDate;

public class Comentario {
    private String nombreVisitante;
    private LocalDate fecha;
    private int puntuacion;
    private String contenido;
    private int idV;
    private int idS;

    public Comentario(String nombreVisitante, int puntuacion, String contenido, int idV, int idS){
        this.nombreVisitante = nombreVisitante;
        this.fecha = null;
        this.puntuacion = puntuacion;
        this.contenido = contenido;
        this.idV = idV;
        this.idS = idS;
    }

    public void setNombreVisitante(String nombreVisitante){
        this.nombreVisitante = nombreVisitante;
    }

    public void setFecha(int year, int mes, int dia){
        this.fecha = LocalDate.of(year, mes, dia);
    }

    public void setPuntuacion(int puntuacion){
        this.puntuacion = puntuacion;
    }

    public void setContenido(String contenido){
        this.contenido = contenido;
    }

    public String getNombreVisitante(){
        return nombreVisitante;
    }

    public LocalDate getFecha(){
        return fecha;
    }

    public int getPuntuacion(){
        return puntuacion;
    }

    public String getContenido(){
        return contenido;
    }

    public int getIdV(){
        return idV;
    }

    public int getIdS(){
        return idS;
    }

    @Override
    public String toString(){
        return ", Nombre de visitante=" + nombreVisitante + '\'' +
                ", Fecha=" + fecha + '\'' +
                ", Puntuacion=" + puntuacion + '\'' +
                ", Contenido=" + contenido + '\'' +
                '}';
    }
}