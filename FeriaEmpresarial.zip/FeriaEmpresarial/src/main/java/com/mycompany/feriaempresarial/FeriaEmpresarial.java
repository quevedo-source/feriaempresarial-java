/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.feriaempresarial;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Juan Diego Quevedo
 */
public class FeriaEmpresarial {
    public FeriaEmpresarial(){
    }

    public void addStand(int id, String ubicacion, String tamano, List<Stand> stands){
        Stand stand = new Stand(id, ubicacion, tamano);
        stands.add(stand);
        System.out.println("Stand añadido");
    }

    public void getStand(List<Stand> stands){
        for(Stand stand : stands){
            System.out.println(stand);
        }
    }

    public void addEmpresa(String nombre, String sector, String correo, List<Empresa> empresas){
        Empresa empresa = new Empresa(nombre, sector, correo);
        empresas.add(empresa);
        System.out.println("Empresa registrada");
    }

    public void deletEmpresa(String nombre, List<Empresa> empresas, List<Stand> standsdis, List<Stand> standsoc){
        empresas.removeIf(e -> e.getNombre().equals(nombre));
        for(Stand stand : standsoc){
            if(stand.getNombreEmpresa().equals(nombre)){
                standsoc.removeIf(e -> e.getNombreEmpresa().equals(nombre));
                stand.setEmpresa(null);
                standsdis.add(stand);
                System.out.println("Empresa eliminada");
                return;
            }
        }
    }

    public void editEmpresa(int opcion, String datocorrect, String datoincorrect, List<Empresa> empresas){
        if(opcion == 1){
            for(Empresa empresa : empresas){
                if(empresa.getNombre().equals(datoincorrect)){
                    empresa.setNombre(datocorrect);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ninguna empresa con ese dato");
        }
        else if(opcion == 2){
            for(Empresa empresa : empresas){
                if(empresa.getSector().equals(datoincorrect)){
                    empresa.setSector(datocorrect);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ninguna empresa con ese dato");
        }
        else if(opcion == 3){
            for(Empresa empresa : empresas){
                if(empresa.getCorreo().equals(datoincorrect)){
                    empresa.setCorreo(datocorrect);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ninguna empresa con ese dato");
        }
        else{
            System.out.println("Opcion incorrecta");
        }
    }

    public void darStand(int id, List<Stand> standsdis, List<Stand> standsoc, String nombre, List<Empresa> empresas){
        for(Empresa empresa : empresas){
            if(empresa.getNombre().equals(nombre)){
                if(standsdis != null){
                    for(Stand stand : standsdis){
                        if(stand.getId() == id){
                            empresa.setStand(stand);
                            stand.setEmpresa(empresa);
                            standsoc.add(stand);
                            standsdis.removeIf(e -> e.getId() == id);
                            System.out.println("Stand añadido a " + nombre);
                            return;
                        }
                    }
                    System.out.println("No se encontro un Stand con ese id, intente de nuevo");
                    return;
                }
                System.out.println("No hay stands disponibles");
                return;
            }
        }
        System.out.println("No se encontro una Empresa con ese nombre, intente de nuevo");
    }

    public void addVisitante(String nombre, int id, String correo, List<Visitante> visitantes){
        Visitante visitante = new Visitante(nombre, id, correo);
        visitantes.add(visitante);
        System.out.println("Visitante registrado");
    }

    public void deletVisitante(int id, List<Visitante> visitantes){
        visitantes.removeIf(e -> e.getId() == id);
        System.out.println("Visitante eliminado");
    }

    public void editVisitante(int opcion, String datocorrect, String datoincorrect, int idinc, int idcor,  List<Visitante> visitantes){
        if(opcion == 1){
            for(Visitante visitante : visitantes){
                if(visitante.getNombre().equals(datoincorrect)){
                    visitante.setNombre(datocorrect);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ningun visitante con ese dato");
        }
        else if(opcion == 2){
            for(Visitante visitante : visitantes){
                if(visitante.getId() == idinc){
                    visitante.setId(idcor);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ningun visitante con ese dato");
        }
        else if(opcion == 3){
            for(Visitante visitante : visitantes){
                if(visitante.getCorreo().equals(datoincorrect)){
                    visitante.setCorreo(datocorrect);
                    System.out.println("Dato corregido");
                    return;
                }
            }
            System.out.println("No se encontro ningun visitante con ese dato");
        }
        else{
            System.out.println("Opcion incorrecta");
        }
    }

    public void addComentario(int idV, int idS, List<Visitante> visitantes, List<Stand> stands, String nombre, int year, int mes, int dia, int puntuacion, String contenido){
        for(Visitante visitante : visitantes){
            if(visitante.getId() == idV){
                for(Stand stand : stands){
                    if(stand.getId() == idS){
                        Comentario comentario = new Comentario(nombre, puntuacion, contenido, idV, idS);
                        visitante.addComentario(comentario, year, mes, dia);
                        visitante.addStand(stand);
                        stand.addComentario(comentario, year, mes, dia);
                        stand.addVisitante(visitante);
                        System.out.println("Hecho!!");
                        return;
                    }
                }
                System.out.println("No se encontro un Stand con ese id, intente de nuevo");
                return;
            }
        }
        System.out.println("No se encontro un Visitante con ese id, intente de nuevo");
    }

    public void reporteEyS(List<Empresa> empresas){
        for(Empresa empresa : empresas){
            System.out.println(empresa);
        }
    }

    public void reporteVyS(List<Visitante> visitantes){
        for(Visitante visitante : visitantes){
            System.out.println(visitante);
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        FeriaEmpresarial feriaempresarial = new FeriaEmpresarial();
        List<Empresa> empresas = new ArrayList<>();
        List<Visitante> visitantes = new ArrayList<>();
        List<Stand> standsdis = new ArrayList<>();
        List<Stand> standsoc = new ArrayList<>();

        String nombre, sector, correo, ubicacion, tamano, contenido;
        int opcion, idV, idS, puntuacion, year, mes, dia;

        int simulacion = 1;
        int opcions;

        System.out.println("Bienvenido a la Feria Empresarial");
        while(simulacion == 1){
            System.out.println("Seleccione una opcion:");
            System.out.println("1. Añadir stand");
            System.out.println("2. Stands disponibles");
            System.out.println("3. Stands ocupados");
            System.out.println("4. Registrar una Empresa");
            System.out.println("5. Editar Empresa");
            System.out.println("6. Eliminar empresa");
            System.out.println("7. Registrar un stand a empresa");
            System.out.println("8. Registrar visitante");
            System.out.println("9. Editar visitante");
            System.out.println("10. Eliminar visitante");
            System.out.println("11. Hacer comentario y calificacion");
            System.out.println("12. Reporte de Empresas y Stands");
            System.out.println("13. Reporte de Visitantes y Stands");
            opcions = sc.nextInt();
            sc.nextLine();
            switch (opcions) {
                case 1:
                    System.out.println("Ingrese la cantidad de stands a añadir:");
                    int cantidadStands = sc.nextInt();
                    sc.nextLine();
                    for(int i = 0; i < cantidadStands; i++){
                        System.out.println("Ingrese el id del stand:");
                        idS = sc.nextInt();
                        sc.nextLine();
                        System.out.println("Ingrese la ubicacion del stand:");
                        ubicacion = sc.nextLine();
                        System.out.println("Ingrese el tamaño del stand:");
                        tamano = sc.nextLine();
                        feriaempresarial.addStand(idS, ubicacion, tamano, standsdis);
                    }
                    break;
                case 2:
                    System.out.println("Stands Disponibles:");
                    feriaempresarial.getStand(standsdis);
                    break;
                case 3:
                    System.out.println("Stands Ocupados:");
                    feriaempresarial.getStand(standsoc);
                    break;
                case 4:
                    System.out.println("Ingrese la cantidad de empresas a registrar:");
                    int cantidadEmpresas = sc.nextInt();
                    sc.nextLine();
                    for(int i = 0; i < cantidadEmpresas; i++){
                        System.out.println("Ingrese el nombre de la empresa:");
                        nombre = sc.nextLine();
                        System.out.println("Ingrese el sector de la empresa:");
                        sector = sc.nextLine();
                        System.out.println("Ingrese el correo de la empresa:");
                        correo = sc.nextLine();
                        feriaempresarial.addEmpresa(nombre, sector, correo, empresas);
                    }
                    break;
                case 5:
                    System.out.println("Que dato desea editar:");
                    System.out.println("1. Nombre");
                    System.out.println("2. Sector");
                    System.out.println("3. Correo");
                    opcion = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el dato incorrecto:");
                    String datoincorrect = sc.nextLine();
                    System.out.println("Ingrese el dato correcto:");
                    String datocorrect = sc.nextLine();
                    feriaempresarial.editEmpresa(opcion, datocorrect, datoincorrect, empresas);
                    break;
                case 6:
                    System.out.println("Ingrese el nombre de la empresa a eliminar:");
                    nombre = sc.nextLine();
                    feriaempresarial.deletEmpresa(nombre, empresas, standsdis, standsoc);
                    break;
                case 7:
                    System.out.println("Ingrese el id del stand:");
                    idS = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el nombre de la empresa:");
                    nombre = sc.nextLine();
                    feriaempresarial.darStand(idS, standsdis, standsoc, nombre, empresas);
                    break;
                case 8:
                    System.out.println("Ingrese la cantidad de visitantes a registrar:");
                    int cantidadVisitantes = sc.nextInt();
                    sc.nextLine();
                    for(int i = 0; i < cantidadVisitantes; i++){
                        System.out.println("Ingrese el nombre del visitante:");
                        nombre = sc.nextLine();
                        System.out.println("Ingrese el id del visitante:");
                        idV = sc.nextInt();
                        sc.nextLine();
                        System.out.println("Ingrese el correo del visitante:");
                        correo = sc.nextLine();
                        feriaempresarial.addVisitante(nombre, idV, correo, visitantes);
                    }
                    break;
                case 9:
                    System.out.println("Que dato desea editar:");
                    System.out.println("1. Nombre");
                    System.out.println("2. Id");
                    System.out.println("3. Correo");
                    opcion = sc.nextInt();
                    sc.nextLine();
                    if(opcion == 2){
                        System.out.println("Ingrese el dato incorrecto:");
                    int idinc = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el dato correcto:");
                    int idcor = sc.nextInt();
                    sc.nextLine();
                    feriaempresarial.editVisitante(opcion, null, null, idinc, idcor, visitantes);;
                    }
                    System.out.println("Ingrese el dato incorrecto:");
                    datoincorrect = sc.nextLine();
                    System.out.println("Ingrese el dato correcto:");
                    datocorrect = sc.nextLine();
                    feriaempresarial.editVisitante(opcion, datocorrect, datoincorrect, 0, 0, visitantes);
                    break;
                case 10:
                    System.out.println("Ingrese el id del visitante:");
                    idV = sc.nextInt();
                    sc.nextLine();
                    feriaempresarial.deletVisitante(idV, visitantes);
                    break;
                case 11:
                    System.out.println("Ingrese el id del visitante que hara el comentario:");
                    idV = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el id del stand a comentar");
                    idS = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el nombre del visitante:");
                    nombre = sc.nextLine();
                    System.out.println("Ingrese el año:");
                    year = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el mes:");
                    mes = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el dia:");
                    dia = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese la puntuacion de 0 a 5:");
                    puntuacion = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Ingrese el comentario:");
                    contenido = sc.nextLine();
                    feriaempresarial.addComentario(idV, idS, visitantes, standsoc, nombre, year, mes, dia, puntuacion, contenido);
                    break;
                case 12:
                    feriaempresarial.reporteEyS(empresas);
                    break;
                case 13:
                    feriaempresarial.reporteVyS(visitantes);
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
            System.out.println("Desea ingresar otra opcion? (1: Si, 0: No)");
            simulacion = sc.nextInt();
            sc.nextLine();
        }
        sc.close();
    }
}